from .methods import methods as Bot
from .message import message as Message
from .tools import tools as Tools

__version__ = '1.0.0'
__author__ = 'MrTelepathic'
__github__ = 'https://github.com/MrTelepathic/SirkPire'
__rubika__ = '@SirkPire'